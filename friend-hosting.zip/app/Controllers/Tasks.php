<?php

namespace App\Controllers;

use App\Models\TaskModel;

class Tasks extends BaseController
{
    /**
     * Complete task listing, ordered by date.
     */
    public function index(): string
    {
        $tasks = new TaskModel();
        $all   = $tasks->getAllOrdered();

        return view('tasks/index', [
            'title'   => 'All tasks',
            'tasks'   => $all,
            'summary' => $tasks->summarize($all),
            'today'   => date('Y-m-d'),
        ]);
    }
}
