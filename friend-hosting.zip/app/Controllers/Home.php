<?php

namespace App\Controllers;

use App\Models\TaskModel;

class Home extends BaseController
{
    /**
     * Dashboard: today's tasks only.
     */
    public function index(): string
    {
        $tasks = new TaskModel();
        $today = $tasks->getToday();

        return view('dashboard/index', [
            'title'   => 'Dashboard',
            'dateStr' => date('l, F j, Y'),
            'tasks'   => $today,
            'summary' => $tasks->summarize($today),
        ]);
    }
}
