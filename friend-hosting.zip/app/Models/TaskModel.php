<?php

namespace App\Models;

use CodeIgniter\Model;

class TaskModel extends Model
{
    public const STATUS_PENDING     = 'pending';
    public const STATUS_IN_PROGRESS = 'in_progress';
    public const STATUS_COMPLETED   = 'completed';

    protected $table            = 'tasks';
    protected $primaryKey       = 'id';
    protected $returnType       = 'array';
    protected $useTimestamps    = false;
    protected $allowedFields    = ['title', 'status', 'task_date', 'created_at'];

    protected $validationRules = [
        'title'     => 'required|max_length[150]',
        'status'    => 'required|in_list[pending,in_progress,completed]',
        'task_date' => 'required|valid_date[Y-m-d]',
    ];

    /**
     * Tasks scheduled for the current date only.
     */
    public function getToday(): array
    {
        return $this->where('task_date', date('Y-m-d'))
                    ->orderBy('id', 'ASC')
                    ->findAll();
    }

    /**
     * Every task on record, earliest date first.
     */
    public function getAllOrdered(): array
    {
        return $this->orderBy('task_date', 'ASC')
                    ->orderBy('id', 'ASC')
                    ->findAll();
    }

    /**
     * Count tasks per status for a given result set.
     *
     * @return array{total:int, pending:int, in_progress:int, completed:int}
     */
    public function summarize(array $tasks): array
    {
        $counts = array_count_values(array_column($tasks, 'status'));

        return [
            'total'       => count($tasks),
            'pending'     => $counts[self::STATUS_PENDING] ?? 0,
            'in_progress' => $counts[self::STATUS_IN_PROGRESS] ?? 0,
            'completed'   => $counts[self::STATUS_COMPLETED] ?? 0,
        ];
    }
}
