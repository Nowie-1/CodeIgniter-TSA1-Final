<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table         = 'users';
    protected $primaryKey    = 'id';
    protected $returnType    = 'array';
    protected $useTimestamps = false;
    protected $allowedFields = ['username', 'full_name', 'email', 'created_at'];

    protected $validationRules = [
        'username'  => 'required|max_length[50]|is_unique[users.username,id,{id}]',
        'full_name' => 'required|max_length[100]',
        'email'     => 'required|valid_email|max_length[100]',
    ];

    /**
     * The demo account shown on the profile page.
     */
    public function getDemoUser(): ?array
    {
        return $this->orderBy('id', 'ASC')->first();
    }
}
