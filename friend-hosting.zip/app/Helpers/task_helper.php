<?php

/**
 * View helpers for the task management pages.
 */

if (! function_exists('status_badge')) {
    /** Render a status as a coloured pill. */
    function status_badge(string $status): string
    {
        $labels = [
            'pending'     => 'Pending',
            'in_progress' => 'In progress',
            'completed'   => 'Completed',
        ];

        $label = $labels[$status] ?? ucfirst(str_replace('_', ' ', $status));

        return sprintf('<span class="badge badge--%s">%s</span>', esc($status, 'attr'), esc($label));
    }
}

if (! function_exists('format_date')) {
    /** Format a Y-m-d (or datetime) string for display. */
    function format_date(string $date, string $format = 'M j, Y'): string
    {
        return date($format, strtotime($date));
    }
}

if (! function_exists('initials')) {
    /** Up to two initials from a full name. */
    function initials(string $name): string
    {
        $parts = preg_split('/\s+/', trim($name)) ?: [];
        $first = mb_substr($parts[0] ?? '', 0, 1);
        $last  = count($parts) > 1 ? mb_substr(end($parts), 0, 1) : '';

        return mb_strtoupper($first . $last);
    }
}
