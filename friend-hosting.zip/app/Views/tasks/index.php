<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="page-head">
    <div>
        <p class="eyebrow"><?= esc($summary['total']) ?> tasks · sorted by date</p>
        <h1>All tasks</h1>
    </div>
    <a class="btn btn--ghost" href="<?= base_url() ?>">Back to today</a>
</div>

<section class="card">
    <?= view('partials/task_table', ['tasks' => $tasks, 'showDate' => true, 'today' => $today]) ?>
</section>
<?= $this->endSection() ?>
