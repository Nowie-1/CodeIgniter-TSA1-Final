<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="page-head">
    <div>
        <p class="eyebrow">Account</p>
        <h1>Profile</h1>
    </div>
</div>

<section class="card profile">
<?php if ($user): ?>
    <div class="profile__header">
        <div class="avatar" aria-hidden="true"><?= esc(initials($user['full_name'])) ?></div>
        <div>
            <h2 class="profile__name"><?= esc($user['full_name']) ?></h2>
            <p class="muted">@<?= esc($user['username']) ?></p>
        </div>
    </div>
    <dl class="details">
        <div><dt>Username</dt><dd><?= esc($user['username']) ?></dd></div>
        <div><dt>Full name</dt><dd><?= esc($user['full_name']) ?></dd></div>
        <div><dt>Email</dt><dd><?= esc($user['email']) ?></dd></div>
        <div><dt>Member since</dt><dd><?= esc(format_date($user['created_at'], 'F j, Y')) ?></dd></div>
    </dl>
<?php else: ?>
    <div class="empty">
        <p class="empty__title">No user found</p>
        <p class="muted">Run <code>php spark db:seed DatabaseSeeder</code> to add the demo account.</p>
    </div>
<?php endif; ?>
</section>
<?= $this->endSection() ?>
