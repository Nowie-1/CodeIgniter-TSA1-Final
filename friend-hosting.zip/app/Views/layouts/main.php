<?php
helper(['url', 'task']);

$path = trim(uri_string(), '/');
$nav  = [
    ''        => 'Dashboard',
    'tasks'   => 'All tasks',
    'profile' => 'Profile',
    'about'   => 'About',
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= esc($title ?? 'Dashboard') ?> · Tasks for Today</title>
    <link rel="stylesheet" href="<?= base_url('assets/css/app.css') ?>">
</head>
<body>
    <header class="topbar">
        <div class="topbar__inner">
            <a class="brand" href="<?= base_url() ?>">
                <span class="brand__mark" aria-hidden="true">
                    <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12.5l4.5 4.5L19 7.5"/></svg>
                </span>
                Tasks for Today
            </a>
            <nav class="nav" aria-label="Main">
                <?php foreach ($nav as $uri => $label): ?>
                    <a href="<?= base_url($uri) ?>" class="nav__link<?= $path === $uri ? ' is-active' : '' ?>"><?= esc($label) ?></a>
                <?php endforeach; ?>
            </nav>
        </div>
    </header>

    <main class="page">
        <?= $this->renderSection('content') ?>
    </main>

    <footer class="footer">Tasks for Today Management System · Built with CodeIgniter 4</footer>
</body>
</html>
