<?php
/**
 * @var array $tasks
 * @var bool  $showDate
 * @var string|null $today
 */
helper('task');
$showDate = $showDate ?? false;
$today    = $today ?? null;
?>
<?php if (empty($tasks)): ?>
    <div class="empty">
        <p class="empty__title">Nothing scheduled</p>
        <p class="muted">There are no tasks to show here yet.</p>
    </div>
<?php else: ?>
    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th class="col-id">#</th>
                    <th>Task</th>
                    <?php if ($showDate): ?><th>Date</th><?php endif; ?>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($tasks as $task): ?>
                <tr>
                    <td class="col-id muted"><?= esc($task['id']) ?></td>
                    <td class="task-title"><?= esc($task['title']) ?></td>
                    <?php if ($showDate): ?>
                        <td class="nowrap">
                            <?= esc(format_date($task['task_date'])) ?>
                            <?php if ($today && $task['task_date'] === $today): ?>
                                <span class="tag">Today</span>
                            <?php endif; ?>
                        </td>
                    <?php endif; ?>
                    <td><?= status_badge($task['status']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>
