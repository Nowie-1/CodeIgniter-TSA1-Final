<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="page-head">
    <div>
        <p class="eyebrow"><?= esc($dateStr) ?></p>
        <h1>Today's tasks</h1>
    </div>
    <a class="btn" href="<?= base_url('tasks') ?>">View all tasks</a>
</div>

<section class="stats">
    <div class="stat">
        <span class="stat__label">Total</span>
        <span class="stat__value"><?= esc($summary['total']) ?></span>
    </div>
    <div class="stat">
        <span class="stat__label">Completed</span>
        <span class="stat__value"><?= esc($summary['completed']) ?></span>
    </div>
    <div class="stat">
        <span class="stat__label">In progress</span>
        <span class="stat__value"><?= esc($summary['in_progress']) ?></span>
    </div>
    <div class="stat">
        <span class="stat__label">Pending</span>
        <span class="stat__value"><?= esc($summary['pending']) ?></span>
    </div>
</section>

<section class="card">
    <?= view('partials/task_table', ['tasks' => $tasks, 'showDate' => false]) ?>
</section>
<?= $this->endSection() ?>
