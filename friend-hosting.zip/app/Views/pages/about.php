<?= $this->extend('layouts/main') ?>

<?= $this->section('content') ?>
<div class="page-head">
    <div>
        <p class="eyebrow">Project</p>
        <h1>About</h1>
    </div>
</div>

<section class="card prose">
    <h2>Developer</h2>
    <p>
        This system was designed and developed by <strong>[YOUR FULL NAME]</strong>
        for IT0049 (Web System Technologies) — Technical Summative Assessment 1,
        FEU Institute of Technology.
    </p>

    <h2>The system</h2>
    <p>
        Tasks for Today Management System is a small internal tool for tracking daily
        to-do items. The dashboard shows only what is scheduled for the current date,
        while the task list gives a complete, date-ordered view of everything on record.
    </p>

    <h2>Built with</h2>
    <ul class="chips">
        <li>CodeIgniter 4</li>
        <li>PHP 8</li>
        <li>MySQL</li>
        <li>MVC architecture</li>
    </ul>
</section>
<?= $this->endSection() ?>
